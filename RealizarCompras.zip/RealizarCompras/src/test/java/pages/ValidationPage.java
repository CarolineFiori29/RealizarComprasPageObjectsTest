package pages;

import org.openqa.selenium.WebDriver;

public class ValidationPage extends BasePage {
    public ValidationPage(WebDriver navegador) {
        super(navegador);
    }
}
